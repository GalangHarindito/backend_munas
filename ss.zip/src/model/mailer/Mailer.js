//require("dotenv").config();

//const EMAIL = process.env.EMAIL

//let mailOptions = new function() {
//  this.name= `${req.body.mailerState.name}`;
//  this.from= `${req.body.mailerState.email}`;
//  this.to= EMAIL;
//  this.subject= `Pesan dari ${req.body.mailerState.name}`;
//  this.text= `<h3>Selamat siang panitia munas,</h3>
//              <p>Anda mendapat pesan dari,</p>
//              <p>Nama : ${this.name}</p>
//              <p>Email : ${this.from}</p>
//              <p>Pesan : ${req.body.mailerState.message}</p>`;
//}

//module.exports = mailOptions;